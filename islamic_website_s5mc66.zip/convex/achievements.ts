import { mutation, query } from "./_generated/server";
import { v } from "convex/values";

export const add = mutation({
  args: { text: v.string() },
  handler: async (ctx, args) => {
    await ctx.db.insert("achievements", { text: args.text });
  },
});

export const list = query({
  args: {},
  handler: async (ctx) => {
    return await ctx.db.query("achievements").order("desc").collect();
  },
});
