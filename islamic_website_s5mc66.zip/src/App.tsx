import { useQuery, useMutation } from "convex/react";
import { api } from "../convex/_generated/api";
import { useState, useEffect } from "react";
import { Toaster, toast } from "sonner";
import { PrayerTimes as Adhan, Coordinates, CalculationMethod } from "adhan";

const SECTIONS = [
  { id: "morning", title: "أذكار الصباح", icon: "🌅" },
  { id: "evening", title: "أذكار المساء", icon: "🌙" },
  { id: "prayer", title: "أذكار بعد الصلاة", icon: "🕌" },
  { id: "prayer-times", title: "مواقيت الصلاة", icon: "⏰" },
  { id: "deceased", title: "أدعية للميت", icon: "🤲" },
  { id: "sick", title: "أدعية للمريض", icon: "🏥" },
  { id: "sleep", title: "أذكار النوم", icon: "😴" },
  { id: "food", title: "أذكار الطعام", icon: "🍽️" },
  { id: "mosque", title: "أذكار المسجد", icon: "🕌" },
  { id: "tasbih", title: "السبحة الإلكترونية", icon: "📿" },
  { id: "achievements", title: "الإنجازات اليومية", icon: "📝" },
  { id: "useful-links", title: "روابط إسلامية مفيدة", icon: "🔗" },
];

const USEFUL_LINKS = [
  {
    title: "السيرة النبوية - أحمد عامر",
    url: "https://www.youtube.com/playlist?list=PLGrAkn4BcLhfDXpqGjqEGXe_7P_kKZ_Ql",
    description: "سلسلة السيرة النبوية كاملة"
  },
  {
    title: "برنامج التقويم الهجري",
    url: "https://calendar.zoznam.sk/islamic_calendar-ar.php",
    description: "تقويم هجري شامل"
  },
  {
    title: "برنامج بلال",
    url: "https://play.google.com/store/apps/details?id=com.bilal.main",
    description: "تطبيق مواقيت الصلاة"
  },
  {
    title: "المصحف الذهبي",
    url: "https://golden-quran.com/",
    description: "القرآن الكريم كاملاً"
  },
  {
    title: "موقع الإسلام سؤال وجواب",
    url: "https://islamqa.info/ar",
    description: "موقع متخصص في الفتاوى الإسلامية"
  },
  {
    title: "موقع طريق الإسلام",
    url: "https://ar.islamway.net/",
    description: "محتوى إسلامي متنوع"
  },
  {
    title: "موسوعة الحديث",
    url: "https://dorar.net/hadith",
    description: "موسوعة الدرر السنية للحديث النبوي"
  }
];

function DhikrCounter({ initialCount = 0 }) {
  const [count, setCount] = useState(initialCount);

  const increment = () => {
    setCount(count + 1);
    if (count + 1 === 33) {
      toast.success("أكملت 33 تسبيحة! 🎉");
    }
    if (count + 1 === 100) {
      toast.success("أكملت 100 تسبيحة! 🌟");
    }
  };

  const decrement = () => {
    if (count > 0) {
      setCount(count - 1);
    }
  };

  const reset = () => {
    setCount(0);
    toast.info("تم إعادة العداد");
  };

  return (
    <div className="flex items-center gap-4 mt-4">
      <button
        onClick={decrement}
        className="bg-red-500 hover:bg-red-600 text-white rounded-full w-10 h-10 flex items-center justify-center shadow-lg transform hover:scale-110 transition-all"
      >
        -
      </button>
      <div className="bg-white rounded-full px-6 py-2 shadow-md text-lg font-bold">
        {count}
      </div>
      <button
        onClick={increment}
        className="bg-green-500 hover:bg-green-600 text-white rounded-full w-10 h-10 flex items-center justify-center shadow-lg transform hover:scale-110 transition-all"
      >
        +
      </button>
      <button
        onClick={reset}
        className="bg-gray-500 hover:bg-gray-600 text-white rounded-full w-10 h-10 flex items-center justify-center shadow-lg transform hover:scale-110 transition-all"
      >
        ↺
      </button>
    </div>
  );
}

function TasbihCounter() {
  const [count, setCount] = useState(0);
  const [selectedDhikr, setSelectedDhikr] = useState("سبحان الله");

  const dhikrOptions = [
    "سبحان الله",
    "الحمد لله",
    "الله أكبر",
    "لا إله إلا الله",
    "أستغفر الله",
    "سبحان الله وبحمده",
    "لا حول ولا قوة إلا بالله",
    "اللهم صل على محمد",
    "سبحان الله والحمد لله ولا إله إلا الله والله أكبر"
  ];

  const increment = () => {
    setCount(count + 1);
    if ((count + 1) % 33 === 0) {
      toast.success("أكملت 33 تسبيحة! 🎉");
    }
    if ((count + 1) % 100 === 0) {
      toast.success("أكملت 100 تسبيحة! 🌟");
    }
  };

  const reset = () => {
    setCount(0);
    toast.info("تم إعادة العداد");
  };

  return (
    <div className="space-y-6">
      <select
        value={selectedDhikr}
        onChange={(e) => setSelectedDhikr(e.target.value)}
        className="w-full p-4 rounded-lg bg-white shadow-md text-lg text-center"
      >
        {dhikrOptions.map((dhikr) => (
          <option key={dhikr} value={dhikr}>
            {dhikr}
          </option>
        ))}
      </select>

      <div className="flex flex-col items-center gap-6">
        <div className="text-6xl font-bold text-emerald-600 bg-white rounded-full w-40 h-40 flex items-center justify-center shadow-lg">
          {count}
        </div>
        
        <button
          onClick={increment}
          className="bg-gradient-to-r from-emerald-500 to-teal-600 text-white rounded-full w-32 h-32 flex items-center justify-center text-4xl shadow-xl transform hover:scale-105 transition-all active:scale-95"
        >
          {selectedDhikr}
        </button>

        <button
          onClick={reset}
          className="bg-gray-500 hover:bg-gray-600 text-white rounded-full px-6 py-3 shadow-lg transform hover:scale-105 transition-all"
        >
          إعادة ⟲
        </button>
      </div>
    </div>
  );
}

function PrayerTimes() {
  const [prayerTimes, setPrayerTimes] = useState<any>(null);
  const [nextPrayer, setNextPrayer] = useState<string>("");
  const [timeToNextPrayer, setTimeToNextPrayer] = useState<string>("");

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((position) => {
        const coordinates = new Coordinates(
          position.coords.latitude,
          position.coords.longitude
        );
        const date = new Date();
        const params = CalculationMethod.Egyptian();
        const prayerTimes = new Adhan(coordinates, date, params);

        setPrayerTimes({
          fajr: prayerTimes.fajr,
          sunrise: prayerTimes.sunrise,
          dhuhr: prayerTimes.dhuhr,
          asr: prayerTimes.asr,
          maghrib: prayerTimes.maghrib,
          isha: prayerTimes.isha,
        });
      });
    }
  }, []);

  useEffect(() => {
    if (prayerTimes) {
      const interval = setInterval(() => {
        const now = new Date();
        const prayers = {
          'الفجر': prayerTimes.fajr,
          'الشروق': prayerTimes.sunrise,
          'الظهر': prayerTimes.dhuhr,
          'العصر': prayerTimes.asr,
          'المغرب': prayerTimes.maghrib,
          'العشاء': prayerTimes.isha,
        };

        let next = '';
        let nextTime = null;
        
        for (const [name, time] of Object.entries(prayers)) {
          if (time > now) {
            next = name;
            nextTime = time;
            break;
          }
        }

        if (next && nextTime) {
          setNextPrayer(next);
          const diff = nextTime.getTime() - now.getTime();
          const hours = Math.floor(diff / (1000 * 60 * 60));
          const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
          setTimeToNextPrayer(`${hours}:${minutes.toString().padStart(2, '0')}`);
        }
      }, 1000);

      return () => clearInterval(interval);
    }
  }, [prayerTimes]);

  if (!prayerTimes) {
    return (
      <div className="text-center p-8">
        جاري تحميل مواقيت الصلاة...
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-emerald-500 to-teal-600 text-white p-6 rounded-lg shadow-lg">
        <h3 className="text-xl font-bold mb-2">الصلاة القادمة</h3>
        <div className="text-3xl font-bold">{nextPrayer}</div>
        <div className="text-lg opacity-90">متبقي: {timeToNextPrayer}</div>
      </div>

      <div className="grid gap-4">
        {Object.entries({
          'الفجر': prayerTimes.fajr,
          'الشروق': prayerTimes.sunrise,
          'الظهر': prayerTimes.dhuhr,
          'العصر': prayerTimes.asr,
          'المغرب': prayerTimes.maghrib,
          'العشاء': prayerTimes.isha,
        }).map(([name, time]) => (
          <div
            key={name}
            className="bg-white/80 backdrop-blur p-4 rounded-lg shadow-md flex justify-between items-center hover:bg-white/90 transition-all transform hover:scale-102"
          >
            <span className="font-bold text-lg">{name}</span>
            <span className="text-gray-600">
              {time.toLocaleTimeString('ar-SA', {
                hour: '2-digit',
                minute: '2-digit',
                hour12: true
              })}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState("morning");
  
  const adhkar = useQuery(api.adhkar.getByCategory, { category: activeSection });
  const duas = useQuery(api.duas.getByCategory, { category: activeSection });
  const achievements = useQuery(api.achievements.list);
  const addAchievement = useMutation(api.achievements.add);

  const [newAchievement, setNewAchievement] = useState("");

  const handleAddAchievement = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newAchievement.trim()) {
      await addAchievement({ text: newAchievement });
      setNewAchievement("");
      toast.success("تم إضافة الإنجاز بنجاح!");
    }
  };

  return (
    <div className="min-h-screen flex bg-gradient-to-br from-emerald-50 to-teal-50 text-right" dir="rtl">
      {/* Sidebar */}
      <aside 
        className={`fixed inset-y-0 right-0 w-72 bg-gradient-to-b from-emerald-600 to-teal-700 text-white shadow-xl transform transition-transform duration-300 ease-in-out ${
          isMenuOpen ? 'translate-x-0' : 'translate-x-full'
        } lg:translate-x-0 lg:static z-50`}
      >
        <div className="h-full flex flex-col p-4">
          <div className="text-3xl font-bold mb-8 text-center p-4 border-b border-emerald-500/30">
            حصن المسلم
          </div>
          <nav className="space-y-2 flex-1 overflow-y-auto">
            {SECTIONS.map((section) => (
              <button
                key={section.id}
                onClick={() => {
                  setActiveSection(section.id);
                  setIsMenuOpen(false);
                }}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all transform hover:scale-102 ${
                  activeSection === section.id
                    ? "bg-white/20 text-white shadow-inner"
                    : "hover:bg-white/10"
                }`}
              >
                <span className="text-xl">{section.icon}</span>
                <span className="font-medium">{section.title}</span>
              </button>
            ))}
          </nav>
          <div className="p-4 text-center text-sm text-white/70 border-t border-emerald-500/30">
            تم التطوير بواسطة فريق حصن المسلم
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-8 lg:pr-80">
        <button
          onClick={() => setIsMenuOpen(!isMenuOpen)}
          className="lg:hidden fixed top-4 right-4 z-50 bg-emerald-600 text-white p-2 rounded-lg shadow-lg"
        >
          {isMenuOpen ? "✕" : "☰"}
        </button>

        <div className="max-w-3xl mx-auto">
          <h1 className="text-3xl font-bold text-emerald-800 mb-8 flex items-center gap-3 bg-white/50 p-4 rounded-lg shadow-sm">
            <span className="text-2xl">
              {SECTIONS.find(s => s.id === activeSection)?.icon}
            </span>
            {SECTIONS.find(s => s.id === activeSection)?.title}
          </h1>

          <div className="space-y-6">
            {activeSection === "prayer-times" ? (
              <PrayerTimes />
            ) : activeSection === "useful-links" ? (
              <div className="grid gap-6">
                {USEFUL_LINKS.map((link, index) => (
                  <a
                    key={index}
                    href={link.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bg-white/80 backdrop-blur rounded-lg p-6 shadow-lg hover:shadow-xl transition-all transform hover:-translate-y-1 border border-emerald-100"
                  >
                    <h3 className="text-xl font-semibold mb-2 text-emerald-800">
                      {link.title}
                    </h3>
                    <p className="text-gray-600">
                      {link.description}
                    </p>
                  </a>
                ))}
              </div>
            ) : activeSection === "tasbih" ? (
              <TasbihCounter />
            ) : activeSection === "achievements" ? (
              <div className="space-y-6">
                <form onSubmit={handleAddAchievement} className="bg-white/80 backdrop-blur rounded-lg p-6 shadow-lg">
                  <input
                    type="text"
                    value={newAchievement}
                    onChange={(e) => setNewAchievement(e.target.value)}
                    placeholder="أضف إنجازاً جديداً..."
                    className="w-full p-4 rounded-lg border border-emerald-200 focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                  />
                  <button
                    type="submit"
                    className="mt-4 bg-emerald-600 text-white px-6 py-3 rounded-lg shadow-lg hover:bg-emerald-700 transition-colors"
                  >
                    إضافة ✓
                  </button>
                </form>
                <div className="space-y-4">
                  {(achievements || []).map((achievement) => (
                    <div
                      key={achievement._id}
                      className="bg-white/80 backdrop-blur rounded-lg p-4 shadow-md flex items-center justify-between"
                    >
                      <span>{achievement.text}</span>
                      <span className="text-sm text-gray-500">
                        {new Date(achievement._creationTime).toLocaleDateString('ar-SA')}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="grid gap-6">
                {(adhkar || []).map((dhikr, index) => (
                  <div
                    key={index}
                    className="bg-white/80 backdrop-blur rounded-lg p-6 shadow-lg hover:shadow-xl transition-all border border-emerald-100 group relative overflow-hidden"
                  >
                    <div className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-emerald-300 to-teal-400 transform scale-x-0 group-hover:scale-x-100 transition-transform duration-500"></div>
                    <h3 className="text-xl font-semibold mb-4 text-emerald-800">
                      {dhikr.title}
                    </h3>
                    <p className="text-lg leading-relaxed mb-4 font-arabic">
                      {dhikr.content}
                    </p>
                    <DhikrCounter />
                    {dhikr.source && (
                      <div className="text-gray-500 text-sm mt-4 border-t pt-4">
                        المصدر: {dhikr.source}
                      </div>
                    )}
                    {dhikr.count && (
                      <div className="absolute top-4 left-4 bg-emerald-100 text-emerald-800 px-3 py-1 rounded-full text-sm">
                        {dhikr.count} مرات
                      </div>
                    )}
                  </div>
                ))}
                {(duas || []).map((dua, index) => (
                  <div
                    key={index}
                    className="bg-white/80 backdrop-blur rounded-lg p-6 shadow-lg hover:shadow-xl transition-all border border-emerald-100 group relative overflow-hidden"
                  >
                    <div className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-emerald-300 to-teal-400 transform scale-x-0 group-hover:scale-x-100 transition-transform duration-500"></div>
                    <h3 className="text-xl font-semibold mb-4 text-emerald-800">
                      {dua.title}
                    </h3>
                    <p className="text-lg leading-relaxed mb-4 font-arabic">
                      {dua.arabic}
                    </p>
                    <p className="text-gray-600 bg-gray-50 p-4 rounded-lg">
                      {dua.translation}
                    </p>
                    <DhikrCounter />
                    {dua.source && (
                      <div className="text-gray-500 text-sm mt-4 border-t pt-4">
                        المصدر: {dua.source}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </main>
      <Toaster />
    </div>
  );
}
