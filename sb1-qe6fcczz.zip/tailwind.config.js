/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        'olive': {
          50: '#f9faf5',
          100: '#f1f4e8',
          200: '#dfe5cc',
          300: '#c5cea8',
          400: '#a5b078',
          500: '#8b9654',
          600: '#556B2F',
          700: '#5c6436',
          800: '#4a512c',
          900: '#3d4225',
          950: '#1f2212',
        },
      },
    },
  },
  plugins: [],
};