import { Product } from '../types';

export const products: Product[] = [
  {
    id: 1,
    name: 'قميص كلاسيك أبيض',
    price: 599,
    image: 'https://images.unsplash.com/photo-1604695573706-53170668f6a6',
    description: 'قميص رجالي كلاسيك مناسب للمناسبات الرسمية',
    category: 'قمصان',
    sizes: ['S', 'M', 'L', 'XL'],
    colors: ['أبيض', 'أزرق فاتح', 'أزرق داكن'],
    rating: 4.5,
    discount: 0
  },
  {
    id: 2,
    name: 'بنطلون جينز عصري',
    price: 799,
    image: 'https://images.unsplash.com/photo-1584865288642-42078afe6942',
    description: 'بنطلون جينز رجالي عصري بقصة مستقيمة',
    category: 'بناطيل',
    sizes: ['30', '32', '34', '36'],
    colors: ['أزرق داكن', 'أسود'],
    rating: 4.8,
    discount: 15
  },
  {
    id: 3,
    name: 'تيشيرت قطن أساسي',
    price: 299,
    image: 'https://images.unsplash.com/photo-1583743814966-8936f5b7be1a',
    description: 'تيشيرت قطن رجالي مريح بقصة عصرية',
    category: 'تيشيرتات',
    sizes: ['M', 'L', 'XL', 'XXL'],
    colors: ['أبيض', 'أسود', 'رمادي'],
    rating: 4.2,
    discount: 0
  },
  {
    id: 4,
    name: 'جاكيت جلد أنيق',
    price: 1599,
    image: 'https://images.unsplash.com/photo-1551028719-00167b16eac5',
    description: 'جاكيت جلد رجالي أنيق مناسب للخروجات',
    category: 'جواكت',
    sizes: ['M', 'L', 'XL'],
    colors: ['بني', 'أسود'],
    rating: 4.9,
    discount: 20
  }
];

export const categories = [...new Set(products.map(p => p.category))];