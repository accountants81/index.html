import React from 'react';
import { Phone, Mail, MapPin, Apple as WhatsApp } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-xl font-bold mb-4">تواصل معنا</h3>
            <div className="space-y-2">
              <a href="tel:01050543116" className="flex items-center gap-2">
                <Phone className="h-5 w-5" />
                01050543116
              </a>
              <a href="mailto:searchemail85@gmail.com" className="flex items-center gap-2">
                <Mail className="h-5 w-5" />
                searchemail85@gmail.com
              </a>
              <a href="https://wa.me/201050543116" className="flex items-center gap-2">
                <WhatsApp className="h-5 w-5" />
                واتساب
              </a>
              <div className="flex items-center gap-2">
                <MapPin className="h-5 w-5" />
                المنوفية، مصر
              </div>
            </div>
          </div>
          
          <div>
            <h3 className="text-xl font-bold mb-4">روابط سريعة</h3>
            <ul className="space-y-2">
              <li><a href="/">الرئيسية</a></li>
              <li><a href="/products">المنتجات</a></li>
              <li><a href="/cart">سلة المشتريات</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-xl font-bold mb-4">عن المتجر</h3>
            <p>متجر AAAMO للملابس الرجالية الفاخرة، نقدم أحدث صيحات الموضة العالمية بجودة عالية وأسعار مناسبة.</p>
          </div>
        </div>
        
        <div className="mt-8 pt-8 border-t border-gray-700 text-center">
          <p>© {new Date().getFullYear()} AAAMO - جميع الحقوق محفوظة</p>
        </div>
      </div>
    </footer>
  );
}