import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import emailjs from '@emailjs/browser';
import { shippingRates } from '../data/shipping';

export default function Cart() {
  const { items, removeFromCart, updateQuantity, total, clearCart } = useCart();
  const [orderDetails, setOrderDetails] = useState({
    name: '',
    phone: '',
    address: '',
    governorate: 'المنوفية',
    notes: '',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [orderSuccess, setOrderSuccess] = useState(false);

  const selectedShippingRate = shippingRates.find(rate => rate.governorate === orderDetails.governorate);
  const shippingCost = selectedShippingRate?.cost || 0;
  const estimatedDays = selectedShippingRate?.estimatedDays || '3-5';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    try {
      const itemsList = items
        .map(item => {
          const itemTotal = item.price * item.quantity;
          return `${item.name} (${item.quantity}x) - ${itemTotal} ج.م
المقاس: ${item.selectedSize || 'غير محدد'}
اللون: ${item.selectedColor || 'غير محدد'}`;
        })
        .join('\n\n');
      
      const message = `
طلب جديد:
==========
الاسم: ${orderDetails.name}
الهاتف: ${orderDetails.phone}
المحافظة: ${orderDetails.governorate}
العنوان: ${orderDetails.address}
وقت التوصيل المتوقع: ${estimatedDays} يوم عمل

المنتجات:
==========
${itemsList}

التكلفة:
==========
إجمالي المنتجات: ${total} ج.م
مصاريف الشحن: ${shippingCost} ج.م
الإجمالي النهائي: ${total + shippingCost} ج.م

ملاحظات:
==========
${orderDetails.notes || 'لا توجد ملاحظات'}
      `.trim();

      // Send email notification
      await emailjs.send(
        'service_id',
        'template_id',
        {
          to_email: 'searchemail85@gmail.com',
          from_name: orderDetails.name,
          message: message,
        },
        'your_public_key'
      );

      // Send WhatsApp message
      const whatsappUrl = `https://wa.me/201050543116?text=${encodeURIComponent(message)}`;
      window.open(whatsappUrl, '_blank');
      
      // Clear the cart and show success
      clearCart();
      setOrderSuccess(true);
      
    } catch (error) {
      console.error('Error sending order:', error);
      alert('حدث خطأ أثناء إرسال الطلب. يرجى المحاولة مرة أخرى.');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (orderSuccess) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-16 text-center">
        <div className="bg-white p-8 rounded-lg shadow-lg">
          <h2 className="text-3xl font-bold text-green-600 mb-4">تم إرسال طلبك بنجاح!</h2>
          <p className="text-lg mb-6">سنتواصل معك قريباً لتأكيد الطلب.</p>
          <Link
            to="/products"
            className="bg-gray-900 text-white px-6 py-3 rounded-lg hover:bg-gray-800 transition"
          >
            العودة للتسوق
          </Link>
        </div>
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-8 text-center">
        <h2 className="text-2xl font-bold mb-4">سلة المشتريات فارغة</h2>
        <p className="mb-4">لم تقم بإضافة أي منتجات إلى السلة بعد.</p>
        <Link 
          to="/products" 
          className="bg-gray-900 text-white px-6 py-2 rounded-lg hover:bg-gray-800 transition"
        >
          تسوق الآن
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div>
          <h2 className="text-2xl font-bold mb-4">سلة المشتريات</h2>
          <div className="space-y-4">
            {items.map(item => (
              <div key={item.id} className="bg-white p-4 rounded-lg shadow flex gap-4">
                <img src={item.image} alt={item.name} className="w-24 h-24 object-cover rounded" />
                <div className="flex-grow">
                  <h3 className="font-semibold">{item.name}</h3>
                  <p className="text-gray-600">{item.price} ج.م</p>
                  {item.selectedSize && (
                    <p className="text-sm text-gray-500">المقاس: {item.selectedSize}</p>
                  )}
                  {item.selectedColor && (
                    <p className="text-sm text-gray-500">اللون: {item.selectedColor}</p>
                  )}
                  <div className="flex items-center gap-2 mt-2">
                    <button
                      onClick={() => updateQuantity(item.id, Math.max(0, item.quantity - 1))}
                      className="bg-gray-200 px-2 py-1 rounded hover:bg-gray-300 transition"
                    >
                      -
                    </button>
                    <span>{item.quantity}</span>
                    <button
                      onClick={() => updateQuantity(item.id, item.quantity + 1)}
                      className="bg-gray-200 px-2 py-1 rounded hover:bg-gray-300 transition"
                    >
                      +
                    </button>
                    <button
                      onClick={() => removeFromCart(item.id)}
                      className="text-red-500 hover:text-red-600 transition mr-2"
                    >
                      حذف
                    </button>
                  </div>
                </div>
                <div className="text-left">
                  <p className="font-bold">{item.price * item.quantity} ج.م</p>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-4 bg-white p-4 rounded-lg shadow">
            <div className="flex justify-between mb-2">
              <span>إجمالي المنتجات:</span>
              <span>{total} ج.م</span>
            </div>
            <div className="flex justify-between mb-2">
              <span>مصاريف الشحن:</span>
              <span>{shippingCost} ج.م</span>
            </div>
            <div className="flex justify-between font-bold text-lg pt-2 border-t">
              <span>الإجمالي النهائي:</span>
              <span>{total + shippingCost} ج.م</span>
            </div>
          </div>
        </div>

        <div>
          <h2 className="text-2xl font-bold mb-4">تفاصيل الطلب</h2>
          <form onSubmit={handleSubmit} className="bg-white p-6 rounded-lg shadow">
            <div className="space-y-4">
              <div>
                <label className="block mb-1">الاسم</label>
                <input
                  type="text"
                  required
                  className="w-full border rounded p-2"
                  value={orderDetails.name}
                  onChange={e => setOrderDetails({ ...orderDetails, name: e.target.value })}
                />
              </div>
              <div>
                <label className="block mb-1">رقم الهاتف</label>
                <input
                  type="tel"
                  required
                  pattern="^01[0-9]{9}$"
                  placeholder="مثال: 01012345678"
                  className="w-full border rounded p-2"
                  value={orderDetails.phone}
                  onChange={e => setOrderDetails({ ...orderDetails, phone: e.target.value })}
                />
              </div>
              <div>
                <label className="block mb-1">المحافظة</label>
                <select
                  className="w-full border rounded p-2"
                  value={orderDetails.governorate}
                  onChange={e => setOrderDetails({ ...orderDetails, governorate: e.target.value })}
                >
                  {shippingRates.map(rate => (
                    <option key={rate.governorate} value={rate.governorate}>
                      {rate.governorate} - {rate.cost} ج.م ({rate.estimatedDays} يوم عمل)
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block mb-1">العنوان بالتفصيل</label>
                <textarea
                  required
                  className="w-full border rounded p-2"
                  rows={3}
                  value={orderDetails.address}
                  onChange={e => setOrderDetails({ ...orderDetails, address: e.target.value })}
                />
              </div>
              <div>
                <label className="block mb-1">ملاحظات إضافية (اختياري)</label>
                <textarea
                  className="w-full border rounded p-2"
                  rows={3}
                  value={orderDetails.notes}
                  onChange={e => setOrderDetails({ ...orderDetails, notes: e.target.value })}
                />
              </div>
              <button
                type="submit"
                disabled={isSubmitting}
                className={`w-full bg-gray-900 text-white py-3 rounded-lg hover:bg-gray-800 transition ${
                  isSubmitting ? 'opacity-50 cursor-not-allowed' : ''
                }`}
              >
                {isSubmitting ? 'جاري إرسال الطلب...' : 'تأكيد الطلب'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}